package testcases;

import java.io.IOException;

import org.openqa.selenium.By;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import base.BaseHooks;
import pages.LoginPage;

public class VerifyHomePage extends BaseHooks {
	
	@BeforeTest
	public void setValues() {
		excelFileName = "Login";
		testName = "VerifyHomePage";
		testDescription = "Login with valid inputs";
		testCategory = "smoke";
		testAuthor = "Hari";

	}
	
	@Test(dataProvider = "sendData") 
	public void runVerifyHomePage(String username, String password) throws InterruptedException, IOException {
		
	//	LoginPage lp = new LoginPage();
		
		new LoginPage(driver,prop)
		.enterUsername(username)
		.enterPassword(password)
		.clickLoginButton()
		.verifyHomePage();
		
		}

}
