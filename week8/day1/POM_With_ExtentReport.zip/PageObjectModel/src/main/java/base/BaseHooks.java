package base;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.time.Duration;
import java.util.Properties;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Parameters;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.MediaEntityBuilder;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;

import io.github.bonigarcia.wdm.WebDriverManager;
import utils.ReadExcel;


public class BaseHooks {

	public ChromeDriver driver; // driver = null
	public String excelFileName; // initial value is null
	public Properties prop;
	
	public static ExtentReports extent;
	public static ExtentTest test, node;
	public String testName, testDescription, testCategory, testAuthor;
	
	public int takeSnap() throws IOException {
		int ranNumber = (int) (Math.random()* 999999+ 99999999);
		File source = driver.getScreenshotAs(OutputType.FILE);
		File target = new File("./snaps/img"+ranNumber+".png");
		FileUtils.copyFile(source, target);
		
		return ranNumber;

	}
		
	public void reportStep(String msg, String status) throws IOException {
		if(status.equalsIgnoreCase("pass")) {
			node.pass(msg,MediaEntityBuilder.createScreenCaptureFromPath(".././snaps/img"+takeSnap()+".png").build());
		}
		else if(status.equalsIgnoreCase("fail")) {
			node.fail(msg,MediaEntityBuilder.createScreenCaptureFromPath(".././snaps/img"+takeSnap()+".png").build());
			throw new RuntimeException("Look into report for more details");
		}
	}
	
	@BeforeSuite
	public void startReport() {
		ExtentHtmlReporter reporter = new ExtentHtmlReporter("./reports/result.html");
		reporter.setAppendExisting(true);
		extent = new ExtentReports();
		extent.attachReporter(reporter);
	}
	
	@BeforeClass
	public void testcaseDetails() {
		test = extent.createTest(testName, testDescription);
		test.assignCategory(testCategory);
		test.assignAuthor(testAuthor);

	}
	
	@AfterSuite
	public void stopReport() {
		extent.flush();

	}
	
	@Parameters({"language"})
	@BeforeMethod
	public void preCondition(String lang) throws IOException {
		
		node = test.createNode(testName);
		
		//properties file setup
		if(lang.equals("english")) {
			
			FileInputStream fis = new FileInputStream("./src/main/resources/english.properties");
			prop = new Properties();
			prop.load(fis);
		}else if(lang.equals("french")) {
			FileInputStream fis = new FileInputStream("./src/main/resources/french.properties");
			prop = new Properties();
			prop.load(fis);
		}
			
		WebDriverManager.chromedriver().setup();
		driver = new ChromeDriver();
		System.out.println(driver); // 2d2fecb52eeed92786b4d82ee121d0d4
		driver.manage().window().maximize();
		driver.get("http://leaftaps.com/opentaps");
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));
	}

	@DataProvider
	public String[][] sendData() throws IOException {
		String[][] readData = ReadExcel.readData(excelFileName);
		return readData;

	}
	@AfterMethod
	public void postCondition() {
		driver.close();

	}

}
