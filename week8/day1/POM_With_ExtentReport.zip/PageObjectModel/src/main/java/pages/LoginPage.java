package pages;

import java.io.IOException;
import java.util.Properties;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

import base.BaseHooks;

public class LoginPage extends BaseHooks{
	
	public LoginPage(ChromeDriver driver, Properties prop) {
		this.driver = driver;
		this.prop = prop;
	}
	
	
	
				//action+FieldName
	public LoginPage enterUsername(String uName) throws InterruptedException, IOException {
		try {
			driver.findElement(By.id("username")).sendKeys(uName);
			reportStep(uName+" entered successfully","pass");
		} catch (Exception e) {
			reportStep(uName+" is not entered successfully"+e,"fail");
		}
		return this;
	}
	
	public LoginPage enterPassword(String pWord) throws IOException {
		try {
			driver.findElement(By.id("password123")).sendKeys(pWord);
			reportStep(pWord+" entered successfully","pass");
		} catch (Exception e) {
			reportStep(pWord+" is not entered successfully"+e,"fail");
		}
		return this;
	}
	
	public HomePage clickLoginButton() throws IOException {
		try {
			driver.findElement(By.className("decorativeSubmit")).click();
			reportStep("Login button is clicked", "pass");
		} catch (Exception e) {
			reportStep("Login button is not clicked"+e, "fail");
		}
		return new HomePage(driver,prop);

	}

}
