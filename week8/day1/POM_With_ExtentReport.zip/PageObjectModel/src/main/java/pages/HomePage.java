package pages;

import java.io.IOException;
import java.util.Properties;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;

import base.BaseHooks;

public class HomePage extends BaseHooks {
	
	public HomePage(ChromeDriver driver, Properties prop) {
		this.driver = driver;
		this.prop = prop;
	}

	public void verifyHomePage() throws IOException {
		try {
			boolean displayed = driver.findElement(By.linkText("CRM/SFA")).isDisplayed();
			Assert.assertTrue(displayed);
			reportStep("Homepage is displayed", "pass");
		} catch (Exception e) {
			reportStep("Homepage is not displayed", "fail");
		}
	}

	public MyHomePage clickCRMSFALink() {
		driver.findElement(By.linkText("CRM/SFA")).click();
		return new MyHomePage(driver,prop);
	}

}
