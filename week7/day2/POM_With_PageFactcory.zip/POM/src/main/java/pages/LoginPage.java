package pages;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindAll;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.FindBys;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import base.BaseHooks;

public class LoginPage extends BaseHooks {

	public LoginPage(ChromeDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	@CacheLookup
	@FindBy(how = How.CLASS_NAME, using = "inputLogin")
	List<WebElement> elePassword;
	
	@FindBy(how = How.CLASS_NAME, using = "decorativeSubmit")
	WebElement eleLoginButton;

	//AND condition -> all the @FindBy should find a match DOM
	/*
	 * @FindBys({ @FindBy(how = How.CLASS_NAME, using = "inputLogin123"),
	 * 
	 * @FindBy(how = How.XPATH, using = "//input[@id='username']") }) WebElement
	 * eleUsername;
	 */
	
	
	//OR condition -> all the @FindBy should find a match DOM
		@FindAll({ @FindBy(how = How.CLASS_NAME, using = "inputLogin123"),
			@FindBy(how = How.XPATH, using = "//input[@id='username']")
	})
	WebElement eleUsername;

	/*
	 * @CacheLookup
	 * 
	 * @FindBy(how=How.XPATH, using="//input[@id='username']") WebElement
	 * eleUsername;
	 */

	public LoginPage enterUsername() throws InterruptedException {
		// driver.findElement(By.id("username")).sendKeys("Demosalesmanager");
		 eleUsername.sendKeys("Demosalesmanager");
		return this;
	}

	public LoginPage enterPassword() {
		  elePassword.get(1).sendKeys("crmsfa");
		//elePassword.sendKeys("crmsfa");
		// driver.findElement(By.id("password")).sendKeys("crmsfa");
		return this;
	}

	public HomePage clickLoginButton() {
		eleLoginButton.click();
		// driver.findElement(By.className("decorativeSubmit")).click();
		return new HomePage(driver);

	}

	public LoginPage clickLoginButtonForNegativeValue() {
		eleLoginButton.click();
		// driver.findElement(By.className("decorativeSubmit")).click();
		return this;
	}

}
